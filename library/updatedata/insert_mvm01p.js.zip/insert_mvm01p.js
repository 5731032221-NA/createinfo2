const config = require('../config');
const pool = require('node-jt400').pool(config);

module.exports.insert = (async function (req, res, dtf, MBCODE, MBNAT, CTRY3, MBAGEN, MBTYPE) {
    //router.post('/:MBCODE/:MBNAT/:CTRY3/:MBAGEN/:MBTYPE', function (req, res) {

    var village1 = '';
    var village2 = '';
    var floor = '';
    var soi = '';
    var contacthome = '';
    var citizen = '';
    var passport = '';
    var roomnum = '';
    var contactoffice = '';
    var contactoffice_ext = '';

    if (typeof req.body.CONTACT_OFFICE != 'undefined') {
        contactoffice = req.body.CONTACT_OFFICE;
    }

    if (typeof req.body.CONTACT_OFFICE_EXTENSION != 'undefined') {
        contactoffice_ext = req.body.CONTACT_OFFICE_EXTENSION;
    }
    

    if (typeof req.body.ADD_ROOM_NUM != 'undefined') {
        roomnum = req.body.ADD_ROOM_NUM;
    }

    if (typeof req.body.ADD_VILLAGE_1 != 'undefined') {
        village1 = req.body.ADD_VILLAGE_1;
    }

    if (typeof req.body.ADD_VILLAGE_2 != 'undefined') {
        village2 = req.body.ADD_VILLAGE_2;
    }

    if (typeof req.body.ADD_FLOOR != 'undefined') {
        floor = req.body.ADD_FLOOR;
    }

    if (typeof req.body.ADD_SOI != 'undefined') {
        soi = req.body.ADD_SOI;
    }

    if (typeof req.body.CONTACT_HOME != 'undefined') {
        contacthome = req.body.CONTACT_HOME;
    }

    if (req.body.DEMO_NTNL == 'TH') {
        if (checkID(req.body.CUST_ID_OR_PASSPORT)) {
            citizen = req.body.CUST_ID_OR_PASSPORT;
        } else {
            res.status(400).json({
                "RESP_CDE": 402,
                "RESP_MSG": "Invalid Format cust_id_or_passport"
            });
            return;
        }
    }
    else {
        passport = req.body.CUST_ID_OR_PASSPORT;
    }

    if (req.body.DEMO_NTNL != 'TH') {
        citizen = CTRY3 + req.body.CUST_ID_OR_PASSPORT;
    }

    var date_str = '';
    var today = new Date();
    date_str = today.getFullYear().toString() + ((today.getMonth() + 1) < 10 ? '0' : '').toString() + (today.getMonth() + 1).toString() + (today.getDate() < 10 ? '0' : '').toString() + today.getDate();
    var age = parseInt(today.getFullYear().toString()) - parseInt(req.body.DEMO_DOB.toString().substr(0, 4));

    var insert_mcard = "insert into MBRFLIB/MVM01P";
    insert_mcard += " (MBOTEL,MBEXT,MBROOM,MBAPP,MBCODE,MBTTLE,MBTNAM,MBTSUR,MBETLE,MBENAM,MBESUR,MBPUR,MBEXP,MBID,MBBIRH,MBAGE,MBPASS,MBNAT,MBHSTS,MBSEX,MBCHIL,MBJOB,MBSINC,MBHNO,MBHVIL,MBPLA,MBFLR,MBHSOI,MBHRD,MBHPFT,MBHBOR,MBHPRV,MBHPOS,MBHTEL,MBPTEL,MBMEMC,MBDAT,MBEMAIL,MBBRH,MBAGEN,MBFLP)";
    //insert_mcard += " (MBAPP,MBCODE,MBID,MBTTLE,MBTNAM,MBTSUR,MBETLE,MBENAM,MBESUR,MBEXP)";
    insert_mcard += " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    //insert_mcard += " values(?,?,?,?,?,?,?,?,?,?)";
    var insert_mcard_params = []

    if(req.body.DEMO_NTNL != 'TH'){
    insert_mcard_params = [
        contactoffice //MBOTEL
        ,contactoffice_ext //MBEXT
        ,roomnum //MBROOM
        ,02 //MBAPP
        , MBCODE //MBCODE
        , "" //MBTTLE
        , req.body.DEMO_TH_NAME //MBTNAM
        , req.body.DEMO_TH_SURNAME //MBTSUR
        , req.body.DEMO_EN_TITLE //MBETLE
        , req.body.DEMO_EN_NAME //MBENAM
        , req.body.DEMO_EN_SURNAME //MBESUR
        , 11 //MBPUR
        , 999912 //MBEXP
        , citizen //MBID
        , req.body.DEMO_DOB //MBBIRH
        , age //MBAGE
        , passport //MBPASS
        , MBNAT //MBNAT
        , req.body.DEMO_MRTLSTS //MBHSTS
        , req.body.DEMO_GENDER //MBSEX
        , req.body.DEMO_HAVE_KIDS //MBCHIL
        , req.body.DEMO_OCCUP //MBJOB
        , parseInt(today.getFullYear().toString()) //MBSINC
        , req.body.ADD_HOUSE_NUM //MBHNO
        , village1 //MBHVIL
        , village2 //MBPLA
        , floor //MBFLR
        , soi //MBHSOI
        , req.body.ADD_ROAD //MBHRD
        , req.body.ADD_SUB_DISTRICT //MBHPFT
        , req.body.ADD_DISTRICT //MBHBOR
        , req.body.ADD_PROVINCE //MBHPRV
        , req.body.ADD_POSTAL_CODE //MBHPOS
        , contacthome //MBHTEL
        , req.body.CONTACT_MOBILE //MBPTEL
        , "38" //MBMEMC
        , parseInt(date_str) //MBDAT
        , req.body.CONTACT_EMAIL //MBEMAIL
        , 02 //MBBRH
        , MBAGEN //MBAGEN
	, "A" //MBFLG
    ];
    }
    else{
        insert_mcard_params = [
            contactoffice //MBOTEL
            ,contactoffice_ext //MBEXT
            ,roomnum //MBROOM
            ,02 //MBAPP
            , MBCODE //MBCODE
            , "คุณ" //MBTTLE
            , req.body.DEMO_TH_NAME //MBTNAM
            , req.body.DEMO_TH_SURNAME //MBTSUR
            , req.body.DEMO_EN_TITLE //MBETLE
            , req.body.DEMO_EN_NAME //MBENAM
            , req.body.DEMO_EN_SURNAME //MBESUR
            , 11 //MBPUR
            , 999912 //MBEXP
            , citizen //MBID
            , req.body.DEMO_DOB //MBBIRH
            , age //MBAGE
            , passport //MBPASS
            , MBNAT //MBNAT
            , req.body.DEMO_MRTLSTS //MBHSTS
            , req.body.DEMO_GENDER //MBSEX
            , req.body.DEMO_HAVE_KIDS //MBCHIL
            , req.body.DEMO_OCCUP //MBJOB
            , parseInt(today.getFullYear().toString()) //MBSINC
            , req.body.ADD_HOUSE_NUM //MBHNO
            , village1 //MBHVIL
            , village2 //MBPLA
            , floor //MBFLR
            , soi //MBHSOI
            , req.body.ADD_ROAD //MBHRD
            , req.body.ADD_SUB_DISTRICT //MBHPFT
            , req.body.ADD_DISTRICT //MBHBOR
            , req.body.ADD_PROVINCE //MBHPRV
            , req.body.ADD_POSTAL_CODE //MBHPOS
            , contacthome //MBHTEL
            , req.body.CONTACT_MOBILE //MBPTEL
            , MBTYPE //MBMEMC
            , parseInt(date_str) //MBDAT
            , req.body.CONTACT_EMAIL //MBEMAIL
            , 02 //MBBRH
            , MBAGEN //MBAGEN
            , "" //MBFLG
        ];
    }

    //MCRR2P - not implemented yet
    //point_log2_stmt = "";
    console.log('insert_mcard_stmt');
    console.log(insert_mcard_params);

    var result = await pool.insertAndGetId(insert_mcard, insert_mcard_params);

    console.log(result.length);
    console.log(result);

    //res.status(200);
    //res.json(result);
    if (result == 0) {
        return true;
    } else {
        res.status(500).json({
            "RESP_SYSCDE": 200,
            "RESP_DATETIME": dtf,
            "RESP_CDE": 500,
            "RESP_MSG": "Not success, Insert fail(MVM01P)"
        });
        res.end();
    }

});


function checkID(custid) {
    var ssn_ = custid;
    var sum = 0;
    console.log(ssn_);
    if (ssn_.length != 13) {
        console.log("Invalid Citizen ID - Length");
        return false;
    } else {
        for (i = 0, sum = 0; i < 12; i++)
            sum += parseFloat(ssn_.charAt(i)) * (13 - i);
        if ((11 - sum % 11) % 10 != parseFloat(ssn_.charAt(12))) {
            console.log("Invalid Citizen ID - Format");
            return false;
        } else {
            console.log("Valid Citizen ID");
            return true;
        }
    }
}

